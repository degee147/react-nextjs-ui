#### Setup:

```

yarn install

yarn dev
```

```
Unzip to folder
Navigate to folder in terminal
run command npm install
run command npm run dev

Open your browser to http://localhost:3000

```
